Qibla Framework

Contributors: Guido Scialfa
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Description

A WordPress plugin to use in conjunction with Qibla Theme. The framework may not work correctly with other themes.
The plugin follow the http://semver.org/ regarding the version numbers.

Requirements

Php: >= 5.3.x
WordPress: >= 4.6

Installation

The plugin is bundled with Qibla theme and will activate automatically on theme activation.

By the way, to activate the plugin follow

1. Upload `qibla-framework` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

Changelog

See changelog.txt
