<?php
namespace QiblaFramework\Review;

/**
 * Rating Field
 *
 * @author     Guido Scialfa <dev@guidoscialfa.com>
 * @package    QiblaFramework\Review
 * @copyright  Copyright (c) 2017, Guido Scialfa
 * @license    GNU General Public License, version 2
 *
 * Copyright (C) 2017 Guido Scialfa <dev@guidoscialfa.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * Class RatingField
 *
 * @since   1.2.0
 * @author  Guido Scialfa <dev@guidoscialfa.com>
 * @package QiblaFramework\Review
 */
class RatingField extends AbstractReviewField
{
    /**
     * RatingField constructor
     *
     * @since 1.2.0
     */
    public function __construct()
    {
        parent::__construct(array(
            'container_class' => array('dlreview-form__rating', 'comment-form-rating'),
            'type'            => 'radio',
            'name'            => 'qibla_mb_comment_rating',
            'value'           => RatingCommentMeta::getDefaultRatingValue(),
            'label'           => sprintf(
                '%s <span class="required">*</span>',
                esc_html__('Your Rating', 'qibla-framework')
            ),
            'options'         => Rating::getRatingList(),
            'exclude_none'    => true,
            'attrs'           => array(
                'required'      => 'required',
                'aria-required' => 'true',
            ),
        ));
    }
}
