# Qibla Importer

A plugin to import the Qibla demo content.

## Requirements
* **Php** >= 5.3.x
* **WordPress** >= 4.6