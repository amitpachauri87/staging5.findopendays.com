# Qibla WooCommerce Listings

Add relation between WooCommerce products and Listings post type

## Requirements
* **Php** >= 5.3.0
* **WordPress** >= 4.6
* **WooCommerce** >= 3.0.0